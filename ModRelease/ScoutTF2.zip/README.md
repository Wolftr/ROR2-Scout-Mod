# Scout TF2
### Important Note: This is a very early development build! Many things are not functional!

If you would like to help with development in any way the Github page is public and can be found here: https://github.com/Wolftr/ROR2-Scout-Mod

A list of all known bugs exists on Github

Please DM -Wolf-#4229 on Discord with any bugs